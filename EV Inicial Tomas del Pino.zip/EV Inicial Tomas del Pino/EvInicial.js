$(document).ready(() => {
    $(document).on('click','#slug',generateURL);
});

function generateURL(){
    var title = $("#title").val().toLowerCase();
    
    var url = title.split(" ");
    console.log(url);
}